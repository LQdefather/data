package com.example.finalProject.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.finalProject.entity.Tag;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface TagMapper {
    @Insert("insert into tag(content) values (#{content});")
    @Options(useGeneratedKeys = true, keyProperty="tag_id", keyColumn="tag_id")
    void insertTag (Tag tag);

    @Select("SELECT * FROM tag WHERE content = #{content};")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
    })
    Tag selectByContent(String content);
    @Select("SELECT * FROM tag WHERE tag_id = #{tag_id};")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
    })
    Tag selectById(long tag_id);

    @Select("select tag_id from tag where content = #{content}")
    long selectIdByContent(String content);

    @Select("select * from tag")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
            @Result(column = "content", property = "content")
    })
    List<Tag> findAllTag();

    @Select("""
            SELECT tag.tag_id,tag.content, SUM(post.score) AS total_score
            FROM tag_to_post
                     JOIN tag ON tag_to_post.tag_id = tag.tag_id
                     JOIN post ON tag_to_post.post_id = post.post_id
            GROUP BY tag.tag_id
            ORDER BY total_score DESC
            LIMIT #{limit};""")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
            @Result(column = "total_score", property = "total_score")
    })
    List<Tag> findPopByScore(int limit);

    @Select("""
            SELECT tag.tag_id,tag.content, SUM(post.answer_count) AS total_score
            FROM tag_to_post
                     JOIN tag ON tag_to_post.tag_id = tag.tag_id
                     JOIN post ON tag_to_post.post_id = post.post_id
            GROUP BY tag.tag_id
            ORDER BY total_score DESC
            LIMIT #{limit};""")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
            @Result(column = "total_score", property = "total_score")
    })
    List<Tag> findPopByAnswer(int limit);

    @Select("""
            SELECT tag.tag_id,tag.content, SUM(post.view_count) AS total_score
            FROM tag_to_post
                     JOIN tag ON tag_to_post.tag_id = tag.tag_id
                     JOIN post ON tag_to_post.post_id = post.post_id
            GROUP BY tag.tag_id
            ORDER BY total_score DESC
            LIMIT #{limit};""")
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
            @Result(column = "total_score", property = "total_score")
    })
    List<Tag> findPopByView(int limit);

    @Select("""
            SELECT tag.tag_id,tag.content, SUM(post.Score) AS total_score,
            SUM(post.view_count) AS total_view,SUM(post.answer_count) AS total_answer
            FROM tag_to_post
                     JOIN tag ON tag_to_post.tag_id = tag.tag_id
                     JOIN post ON tag_to_post.post_id = post.post_id
            WHERE tag.content = #{content}
            group by tag.tag_id;
            """)
    @Results({
            @Result(column = "tag_id", property = "tag_id"),
            @Result(column = "total_score", property = "total_score"),
            @Result(column = "total_view", property = "total_view"),
            @Result(column = "total_answer", property = "total_answer")
    })
    Tag findPopByContent(String content);
    @Insert("insert into tag_to_post(post_id, tag_id) values (#{post_id},#{tag_id});")
    void insertTagToPost(Long post_id, Long tag_id);

    @Select("select tag_id from tag_to_post where post_id = #{post_id};")
    List<Long> findTagsByPost(long post_id);

    @Select("select post_id from tag_to_post where tag_id = #{tag_id};")
    List<Long> findPostsByTag(long tag_id);
}
