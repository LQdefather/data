package com.example.finalProject.entity;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class Bug {
    String name;
    int count_post;


    public Bug(String name, int count_post) {
        this.name = name;
        this.count_post = count_post;
    }
}
