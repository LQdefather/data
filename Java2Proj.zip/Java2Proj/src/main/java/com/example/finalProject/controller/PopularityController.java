package com.example.finalProject.controller;

import com.example.finalProject.entity.Tag;
import com.example.finalProject.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pop")
public class PopularityController {
    final
    TagService tagService;

    public PopularityController(TagService tagService) {
        this.tagService = tagService;
    }

    @GetMapping("/topScore/{limit}")
    public List<Tag> findPopByScore(@PathVariable int limit){
        List<Tag> tags = tagService.findPopByScore(limit);
        return tags;
    }
    @GetMapping("/topAnswer/{limit}")
    public List<Tag> findPopByAnswer(@PathVariable int limit){
        List<Tag> tags = tagService.findPopByAnswer(limit);
        return tags;
    }
    @GetMapping("/topView/{limit}")
    public List<Tag> findPopByView(@PathVariable int limit){
        List<Tag> tags = tagService.findPopByView(limit);
        return tags;
    }

    @GetMapping("/query/{content}")
    public Tag findPopByContent(@PathVariable String content){
        Tag tag = tagService.findPopByContent(content);
        return tag;
    }
    @GetMapping("/topTopic/{limit}")
    public List<Tag> findPopByCom(@PathVariable int limit){
        List<Tag> tags = tagService.findPopCom(limit);
        return tags;
    }

//    @GetMapping("/test/{post_id}")
//    public List<Long> test (@PathVariable long post_id){
//        return tagService.findTagsByPost(post_id);
//    }

}
