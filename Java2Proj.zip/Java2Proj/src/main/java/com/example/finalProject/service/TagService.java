package com.example.finalProject.service;

import com.example.finalProject.entity.Post;
import com.example.finalProject.entity.Tag;
import com.example.finalProject.mapper.PostMapper;
import com.example.finalProject.mapper.TagMapper;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@Service
public class TagService {
    final
    TagMapper tagMapper;
    final
    PostMapper postMapper;

    public TagService(TagMapper tagMapper,PostMapper postMapper) {
        this.tagMapper = tagMapper;
        this.postMapper = postMapper;
    }

    public List<Tag> findPopByScore(int limit){
        return tagMapper.findPopByScore(limit);
    }

    public List<Tag> findPopByAnswer(int limit){
        return tagMapper.findPopByAnswer(limit);
    }

    public List<Tag> findPopByView(int limit){
        return tagMapper.findPopByView(limit);
    }

    public Tag findPopByContent(String content){
        return tagMapper.findPopByContent(content);
    }

    public List<Tag> findPopCom(int limit){
        List<Tag> tags = tagMapper.findAllTag();
        for (Tag tag:tags){
            List<Long> posts = tagMapper.findPostsByTag(tag.getTag_id());
            int total_view = 0;
            int total_answer = 0;
            int total_score = 0;
            for (long tmp:posts){
                Post post = postMapper.selectById(tmp);
                total_view+=post.getView_count();
                total_answer+= post.getAnswer_count();
                total_score+= post.getScore();
            }
            tag.setTotal_view(total_view);
            tag.setTotal_score(total_score);
            tag.setTotal_answer(total_answer);
            tag.setTag_score(total_score*100L+(long) Math.sqrt(total_view)+total_answer* 50L);
        }

        tags.sort(Comparator.comparingLong(Tag::getTag_score).reversed());
        List<Tag> topTags = tags.subList(0, Math.min(tags.size(), limit));
        long max = topTags.get(0).getTag_score();
        for (Tag tag : topTags){
            tag.setTag_score((long)((double)tag.getTag_score()/(double)max * 100));
        }
        return topTags;
    }

//    public List<Long> findTagsByPost(long post_id){
//        return tagMapper.findTagsByPost(post_id);
//    }
}
