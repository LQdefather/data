package com.example.finalProject.service;

import com.example.finalProject.entity.Answer;
import com.example.finalProject.entity.Bug;
import com.example.finalProject.entity.Post;
import com.example.finalProject.entity.Tag;
import com.example.finalProject.mapper.AnswerMapper;
import com.example.finalProject.mapper.PostMapper;
import com.example.finalProject.mapper.TagMapper;
import org.apache.poi.ss.formula.functions.T;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class PostService {
    final
    PostMapper postMapper;
    final
    TagMapper tagMapper;
    final
    AnswerMapper answerMapper;

    public PostService(PostMapper postMapper, TagMapper tagMapper, AnswerMapper answerMapper) {
        this.postMapper = postMapper;
        this.tagMapper = tagMapper;
        this.answerMapper = answerMapper;
    }

    public List<Post> allPost() {
        return postMapper.allPost();
    }

    public Bug queryBug(String name) {
        name = name.replaceAll("\\s", "");
        int count_post = 0;
//        List<Post> bugPosts = new ArrayList<>();
        List<Post> posts = allPost();
        for (Post post : posts) {
            List<Long> tags = tagMapper.findTagsByPost(post.getPost_id());
            Tag tag = tagMapper.findPopByContent(name);
            if (tag != null && tags.contains(tag.getTag_id())) {

                count_post++;
            } else {
                if (getCount(name,post.getContent())){

                    count_post++;
                    continue;
                }
                if (post.getAnswer_count()>0){
                    List<Answer> answers = answerMapper.findByPost(post.getPost_id());
                    for (Answer answer: answers){
                        if (getCount(name,answer.getContent())){
                            count_post++;
                            break;
                        }
                    }
                }
            }

        }
        return new Bug(name, count_post);
    }

    public List<Tag> findRelatedTags(String content){
        Tag tag = tagMapper.selectByContent(content);
        if (tag == null){
            if (content.contains(" ")) {
                content = content.replaceAll(" ", "-");
                return findRelatedTags(content);
            }
            if (content.contains("-")) {
                String[] strings = content.split("-");
                List<Tag> out = new ArrayList<>();
                for (String s : strings){
                    out.addAll(findRelatedTags(s));
                }
                out.sort(Comparator.comparingDouble(Tag::getRelated_rate).reversed());
                out = out.subList(0, Math.min(out.size(), 10));
                return out;
            } else {
                return new ArrayList<>();
            }
        }

        List<Long> input = tagMapper.findPostsByTag(tagMapper.selectIdByContent(content));
        System.out.println(input);
        List<Long> tags = new ArrayList<>();
        List<Tag> out = new ArrayList<>();
        for (long post:input){
            Post temp = postMapper.selectById(post);
            List<Long> tagsToTemp = tagMapper.findTagsByPost(temp.getPost_id());
            for (long tagToTemp:tagsToTemp){
                if (!tags.contains(tagToTemp)){
                    tags.add(tagToTemp);
                }
            }
        }
        for (long findTag:tags){
            Tag tempTag = tagMapper.selectById(findTag);
            List<Long> find = tagMapper.findPostsByTag(findTag);
            tempTag.setRelated_rate(calculateRate(input,find));
            out.add(tempTag);
        }
        for (Tag tag1:out){
            if (tag1.getContent().equals(content)){
                out.remove(tag1);
                break;
            }
        }
        out.sort(Comparator.comparingDouble(Tag::getRelated_rate).reversed());
        out = out.subList(0, Math.min(out.size(), 10));
        return out;
    }
    public float calculateRate(List<Long> input,List<Long> find){
        int count = 0 ;
        for (long a : find){
            if (input.contains(a)){
                count++;
            }
        }
        return (float) count / (float) input.size();
    }


    private static boolean getCount(String name,String in) {
        in = in.replaceAll("\\s", "");
        Pattern pattern = Pattern.compile("<p>(.*?)</p>");
        Matcher matcher = pattern.matcher(in);
        while (matcher.find()) {
            if (matcher.group(1).toLowerCase().contains(name.toLowerCase())) {
                System.out.println(matcher.group(1));
                System.out.println("********");
                return true;
            }
        }
        pattern = Pattern.compile("<code>(.*?)</code>");
        matcher = pattern.matcher(in);
        while (matcher.find() && matcher.group(1).toLowerCase().contains(name.toLowerCase())) {
            if (matcher.group(1).toLowerCase().contains(name.toLowerCase())) {
                System.out.println(matcher.group(1));
                System.out.println("********");
                return true;
            }
        }
        return false;
    }

    public void extractedError(List<Bug> errors) {
        errors.add(queryBug("TypeError"));
        errors.add(queryBug("ReferenceError"));
        errors.add(queryBug("SyntaxError"));
        errors.add(queryBug("Class not found"));
        errors.add(queryBug("Type mismatch"));
//        errors.add(queryBug("TypeClassCastExceptionError"));
//        errors.add(queryBug("AccessPrivilegesErrors"));
//        errors.add(queryBug("LogicalError"));
//        errors.add(queryBug("Variable might not have been initialized"));
//        errors.add(queryBug("Duplicate local variable"));
//        errors.add(queryBug("Symbol not found"));
//        errors.add(queryBug("Method not found"));
//        errors.add(queryBug("Mismatched brackets"));
//        errors.add(queryBug("Illegal access"));
//        errors.add(queryBug("Using a reserved word"));
    }
    public void extractedException(List<Bug> exceptions) {
        exceptions.add(queryBug("ClassCastException"));
        exceptions.add(queryBug("Unhandled exception"));
//        exceptions.add(queryBug("NullPointerException"));
//        exceptions.add(queryBug("ArrayIndexOutOfBoundsException"));
//        exceptions.add(queryBug("NumberFormatException"));
//        exceptions.add(queryBug("FileNotFoundException"));
//        exceptions.add(queryBug("IOException"));
//        exceptions.add(queryBug("ArithmeticException"));
//        exceptions.add(queryBug("NumberFormatException"));
//        exceptions.add(queryBug("IndexOutOfBoundsException"));
//        exceptions.add(queryBug("IllegalArgumentException"));
//        exceptions.add(queryBug("ConcurrentModificationException"));
//        exceptions.add(queryBug("NoSuchMethodException"));
//        exceptions.add(queryBug("SecurityException"));
//        exceptions.add(queryBug("IllegalStateException"));
//        exceptions.add(queryBug("NoSuchFieldException"));
//        exceptions.add(queryBug("InvocationTargetException"));
//        exceptions.add(queryBug("NumberFormatException"));

    }

    public void extractedFatal(List<Bug> fatal) {
//        fatal.add(queryBug("OutOfMemoryError"));
//        fatal.add(queryBug("StackOverflowError"));
//        fatal.add(queryBug("InternalError"));
//        fatal.add(queryBug("LinkageError"));
//        fatal.add(queryBug("IncompatibleClassChangeError"));
//        fatal.add(queryBug("AbstractMethodError"));
//        fatal.add(queryBug("ExceptionInInitializerError"));
    }
}
