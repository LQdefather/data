package com.example.finalProject.controller;

import com.example.finalProject.entity.Tag;
import com.example.finalProject.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;

@RestController
@RequestMapping("/Rel")
public class RelatedController {
    final
    PostService postService;

    public RelatedController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping("/query/{content}")
    public List<Tag> queryRelated(@PathVariable String content){
        List<Tag> tags = postService.findRelatedTags(content);
        return tags;
    }
}
