package com.example.finalProject.service;

import com.example.finalProject.entity.Answer;
import com.example.finalProject.entity.Post;
import com.example.finalProject.entity.Tag;
import com.example.finalProject.mapper.AnswerMapper;
import com.example.finalProject.mapper.PostMapper;
import com.example.finalProject.mapper.TagMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class ReadJson {
    final
    PostMapper postMapper;
    final
    AnswerMapper answerMapper;
    final
    TagMapper tagMapper;

    public ReadJson(PostMapper postMapper, AnswerMapper answerMapper, TagMapper tagMapper) {
        this.postMapper = postMapper;
        this.answerMapper = answerMapper;
        this.tagMapper = tagMapper;
    }

    public void readData(String path) {
        String jsonString = null;
        try {
            jsonString = new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // Parse the JSON array
        JSONArray jsonArray = new JSONArray(jsonString);

        // Add data to each JSON object in the array
        for (int i = 0; i < jsonArray.length(); i++) {
//            System.out.println(i);
            JSONObject jsonObject2 = jsonArray.getJSONObject(i);
            JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("question");

            long post_id = jsonObject.getLong("question_id");
            if (postMapper.selectById(post_id) == null) {
                JSONArray data_tags = jsonObject.getJSONArray("tags");
                String[] tags = new String[data_tags.length()];
                for (int k = 0; k < data_tags.length(); k++) {
                    tags[k] = data_tags.getString(k);
                }
                int view_count = jsonObject.getInt("view_count");
                int answer_count = jsonObject.getInt("answer_count");
                int score = jsonObject.getInt("score");
                String title = jsonObject.getString("title");
                String content = jsonObject.getString("body");
                Post post = new Post(post_id, view_count, answer_count, score, title, content);
                postMapper.insertPost(post);
                for (String tag : tags) {
                    Tag tag1 = tagMapper.selectByContent(tag);
                    if (tag1 == null) {
                        tag1 = new Tag();
                        tag1.setContent(tag);
                        tagMapper.insertTag(tag1);
                        tagMapper.insertTagToPost(post_id, tag1.getTag_id());
                    } else {
                        tagMapper.insertTagToPost(post_id, tagMapper.selectIdByContent(tag));
                    }
                }
                if (answer_count > 0) {
                    JSONArray jsonArray1 = new JSONArray(jsonObject2.optJSONArray("answers").getJSONObject(0).getJSONArray("items"));
                    for (int j = 0; j < jsonArray1.length(); j++) {
                        JSONObject jsonObject1 = jsonArray1.getJSONObject(j);
                        long answer_id = jsonObject1.getLong("answer_id");
                        String answer_content = jsonObject1.getString("body");
                        Answer answer = new Answer(answer_id, answer_content);
                        answerMapper.insertAnswer(answer);
                        answerMapper.insertAnsToPost(post_id, answer_id);
                    }
                }
            }
        }
    }
}
