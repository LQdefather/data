package com.example.finalProject.util;

import com.example.finalProject.entity.Answer;
import com.example.finalProject.entity.Post;
import com.example.finalProject.mapper.PostMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.nio.file.Files;
import java.nio.file.Paths;

public class readJson {
    public static void main(String[] args) throws Exception {
        // Read the JSON array file
        String fileName = "output.json";
        String jsonString = new String(Files.readAllBytes(Paths.get(fileName)));

        // Parse the JSON array
        JSONArray jsonArray = new JSONArray(jsonString);

        // Add data to each JSON object in the array
        for (int i = 0; i < jsonArray.length(); i++) {
            System.out.println(i);
            JSONObject jsonObject2 = jsonArray.getJSONObject(i);
            JSONObject jsonObject = jsonArray.getJSONObject(i).getJSONObject("question");

            long post_id = jsonObject.getLong("question_id");
            JSONArray data_tags = jsonObject.getJSONArray("tags");
            String[] tags = new String[data_tags.length()];
            for (int k = 0; k < data_tags.length(); k++) {
                tags[k] = data_tags.getString(k);
            }
            int view_count = jsonObject.getInt("view_count");
            int answer_count = jsonObject.getInt("answer_count");
            int score = jsonObject.getInt("score");
            String title = jsonObject.getString("title");
            String content = jsonObject.getString("body");
            Post post = new Post(post_id,view_count,answer_count,score,title,content);
            if (answer_count > 0){
                JSONArray jsonArray1 = new JSONArray(jsonObject2.optJSONArray("answers").getJSONObject(0).getJSONArray("items"));
                for (int j = 0 ; j< jsonArray1.length() ; j++){
                    JSONObject jsonObject1 = jsonArray1.getJSONObject(j);
                    long answer_id =  jsonObject1.getLong("answer_id");
                    String answer_content = jsonObject1.getString("body");
                    Answer answer = new Answer(answer_id,answer_content);
                }
            }
        }
    }


}