package com.example.finalProject.controller;

import com.example.finalProject.service.ReadJson;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class TestController {
    final
    ReadJson readJson;

    public TestController(ReadJson readJson) {
        this.readJson = readJson;
    }

    @GetMapping("/readJsonData")
    //
    public Boolean submitEvaluation(){
        String path = "D:\\qq down\\output.json";
        readJson.readData(path);
        return true;
    }
}
