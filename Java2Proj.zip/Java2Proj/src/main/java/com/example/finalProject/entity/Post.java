package com.example.finalProject.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("post")
public class Post {
    private long post_id;
    private int view_count;
    private int answer_count;
    private int score;
    private String title;
    private String content;

    public Post(long post_id, int view_count, int answer_count, int score, String title, String content) {
        this.post_id = post_id;
        this.view_count = view_count;
        this.answer_count = answer_count;
        this.score = score;
        this.title = title;
        this.content = content;
    }

    public Post() {
    }
}