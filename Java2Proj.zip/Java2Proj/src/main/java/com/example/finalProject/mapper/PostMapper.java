package com.example.finalProject.mapper;

import com.example.finalProject.entity.Post;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PostMapper {
    @Insert("insert into post (post_id, view_count, answer_count, score, title, content)\n" +
            "values (#{post_id},#{view_count},#{answer_count},#{score},#{title},#{content})")
    void insertPost(Post post);

    @Select("select * from post where post_id = #{post_id};")
    @Results({
            @Result(column = "post_id", property = "post_id"),
            @Result(column = "answer_count", property = "answer_count"),
            @Result(column = "view_count", property = "view_count"),
    })
    Post selectById(Long post_id);

    @Select("select * from post;")
    @Results({
            @Result(column = "post_id", property = "post_id"),
            @Result(column = "answer_count", property = "answer_count"),
    })
    List<Post> allPost();
}
