package com.example.finalProject.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("answer")
public class Answer {
    private long answer_id;
    private String content;

    public Answer(long answer_id, String content) {
        this.answer_id = answer_id;
        this.content = content;
    }

    public Answer() {
    }
}