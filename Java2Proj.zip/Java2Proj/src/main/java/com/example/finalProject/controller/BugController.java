package com.example.finalProject.controller;


import com.example.finalProject.entity.Bug;
import com.example.finalProject.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/bug")
public class BugController {
    final
    PostService postService;

    public BugController(PostService postService) {
        this.postService = postService;
    }

    @GetMapping("/queryBug")
    public List<Bug> findPopByView(){
        List<Bug> bugs =new ArrayList<>();
        List<Bug> errors = new ArrayList<>();
        List<Bug> exceptions = new ArrayList<>();
        List<Bug> fatal = new ArrayList<>();
        postService.extractedError(errors);
        int count = 0;
        for (Bug bug1: errors){
            count += bug1.getCount_post();
        }
        Bug bug = new Bug("error",count);
        bugs.add(bug);

        postService.extractedException(exceptions);
        count = 0;
        for (Bug bug1: exceptions){
            count += bug1.getCount_post();
        }
        bug = new Bug("exception",count);
        bugs.add(bug);

        postService.extractedFatal(fatal);
        count = 0;
        for (Bug bug1: fatal){
            count += bug1.getCount_post();
        }
        bug = new Bug("fatal",count);
        bugs.add(bug);

        return bugs;
    }
    @GetMapping("/queryException")
    public List<Bug> findException(){
        List<Bug> errors = new ArrayList<>();
        postService.extractedException(errors);
        return errors;
    }
    @GetMapping("/queryError")
    public List<Bug> findError(){
        List<Bug> exceptions = new ArrayList<>();
        postService.extractedError(exceptions);
        return exceptions;
    }

    @GetMapping("/queryFatal")
    public List<Bug> findFatal(){
        List<Bug> fatal = new ArrayList<>();
        postService.extractedFatal(fatal);
        return fatal;
    }
}
