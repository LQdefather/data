package com.example.finalProject.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.finalProject.entity.Answer;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AnswerMapper{
    @Insert("insert into answer (answer_id, content) values (#{answer_id},#{content});")
    void insertAnswer(Answer answer);

    @Insert("insert into answer_to_post(post_id, answer_id) values (#{post_id},#{answer_id});")
    void insertAnsToPost(long post_id,long answer_id);

    @Select("""
            SELECT a.*
            FROM answer AS a
                     JOIN answer_to_post AS apt ON a.answer_id = apt.answer_id
            WHERE apt.post_id = #{post_id}""")
    List<Answer> findByPost(long post_id);
}
