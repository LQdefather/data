package com.example.finalProject.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("tag")
public class Tag {
    long tag_id;
    String content;
    @TableField(exist = false)
    int total_score;
    @TableField(exist = false)
    int total_view;
    @TableField(exist = false)
    int total_answer;
    @TableField(exist = false)
    float related_rate;
    @TableField(exist = false)
    long tag_score;
    public Tag() {
    }

}
